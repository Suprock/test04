#!/bin/bash

shallname=`readlink -f "$0"`
dirfile=`dirname ${shallname}`

chmod 755 ${dirfile}/bin/*
chmod 755 ${dirfile}/mysql/*
chmod 755 ${dirfile}/installctl
[[ -f ${dirfile}/images ]] || mkdir -p ${dirfile}/images
if sudo ls -l /usr/bin|grep -q 'installctl';then
	sudo ls -l /usr/bin|grep -q "${dirfile}/installctl" || {
		if [[ $1 == "force" ]];then
			sudo rm -rf /usr/bin/installctl
			sudo ln -s ${dirfile}/installctl /usr/bin
		else
			read -p "已存在`sudo ls -l /usr/bin/installctl`,是否重新定向为${dirfile}/installctl.(Y/N)" confirm
			[[ ${confirm} == "Y" ]] && sudo rm -rf /usr/bin/installctl > /dev/null && sudo ln -s ${dirfile}/installctl /usr/bin
		fi
	}
else
	sudo ln -s ${dirfile}/installctl /usr/bin
fi 
sudo cp ${dirfile}/installctl_completion /etc/bash_completion.d/installctl
sudo chmod 644 /etc/bash_completion.d/installctl
sudo grep -q "^source /etc/bash_completion.d/installctl" ~/.bashrc || \
sudo sed -i '$a\source /etc/bash_completion.d/installctl' ~/.bashrc
sudo grep -q "^source /etc/bash_completion.d/installctl" /home/security/.bashrc || \
sudo sed -i '$a\source /etc/bash_completion.d/installctl' /home/security/.bashrc
sudo grep -q "^source /etc/bash_completion.d/installctl" /root/.bashrc || \
sudo sed -i '$a\source /etc/bash_completion.d/installctl' /root/.bashrc
